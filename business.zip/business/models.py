from django.contrib.auth.models import AbstractUser
from django.db import models
from rest_framework import serializers

# Create your models here.
# 用户
class Member(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="编号", help_text="编号")
    username = models.CharField(max_length=255, verbose_name="登录账户 ", null=True, blank=True, help_text="登录账户")
    name = models.CharField(max_length=255, verbose_name="姓名 ", null=True, blank=True, help_text="姓名")
    user_id = models.IntegerField(verbose_name="所属用户", null=True, blank=True, help_text="所属用户")
    phone = models.CharField(max_length=255, verbose_name="手机号码 ", null=True, blank=True, help_text="手机号码")

    @property
    def userId(self):
        return self.user_id

    class Meta:
        db_table = "member"
        verbose_name = "用户"
        verbose_name_plural = verbose_name

class MemberSerializer(serializers.ModelSerializer):
    userId = serializers.SerializerMethodField()

    class Meta:
        model = Member
        fields = '__all__'

    def get_userId(self, obj):
        return obj.user_id


# 失物招领
class Recruit(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="编号", help_text="编号")
    category_id = models.IntegerField(verbose_name="物品分类", null=True, blank=True, help_text="物品分类")
    name = models.CharField(max_length=255, verbose_name="物品名称 ", null=True, blank=True, help_text="物品名称")
    img = models.CharField(max_length=255, verbose_name="物品图片 ", null=True, blank=True, help_text="物品图片")
    content = models.TextField(verbose_name="物品介绍 ",null=True, blank=True,  help_text="物品介绍")
    address = models.CharField(max_length=255, verbose_name="拾取地点 ", null=True, blank=True, help_text="拾取地点")
    time = models.CharField(max_length=255, verbose_name="拾取时间 ", null=True, blank=True, help_text="拾取时间")
    user_id = models.IntegerField(verbose_name="发布者", null=True, blank=True, help_text="发布者")
    create_time = models.DateTimeField(auto_now_add=True, null=True, blank=True, help_text="发布时间", verbose_name="发布时间")

    @property
    def categoryId(self):
        return self.category_id
    @property
    def userId(self):
        return self.user_id
    @property
    def createTime(self):
        return self.create_time

    class Meta:
        db_table = "recruit"
        verbose_name = "失物招领"
        verbose_name_plural = verbose_name

class RecruitSerializer(serializers.ModelSerializer):
    categoryId = serializers.SerializerMethodField()
    userId = serializers.SerializerMethodField()
    createTime = serializers.SerializerMethodField()

    class Meta:
        model = Recruit
        fields = '__all__'

    def get_categoryId(self, obj):
        return obj.category_id
    def get_userId(self, obj):
        return obj.user_id
    def get_createTime(self, obj):
        return obj.create_time

# 物品挂失
class Lost(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="编号", help_text="编号")
    category_id = models.IntegerField(verbose_name="物品分类", null=True, blank=True, help_text="物品分类")
    name = models.CharField(max_length=255, verbose_name="物品名称 ", null=True, blank=True, help_text="物品名称")
    img = models.CharField(max_length=255, verbose_name="物品图片 ", null=True, blank=True, help_text="物品图片")
    content = models.TextField(verbose_name="物品描述 ",null=True, blank=True,  help_text="物品描述")
    address = models.CharField(max_length=255, verbose_name="丢失地点 ", null=True, blank=True, help_text="丢失地点")
    time = models.CharField(max_length=255, verbose_name="丢失时间 ", null=True, blank=True, help_text="丢失时间")
    phone = models.CharField(max_length=255, verbose_name="联系方式 ", null=True, blank=True, help_text="联系方式")
    user_id = models.IntegerField(verbose_name="发布者", null=True, blank=True, help_text="发布者")
    create_time = models.DateTimeField(auto_now_add=True, null=True, blank=True, help_text="发布时间", verbose_name="发布时间")

    @property
    def categoryId(self):
        return self.category_id
    @property
    def userId(self):
        return self.user_id
    @property
    def createTime(self):
        return self.create_time

    class Meta:
        db_table = "lost"
        verbose_name = "物品挂失"
        verbose_name_plural = verbose_name

class LostSerializer(serializers.ModelSerializer):
    categoryId = serializers.SerializerMethodField()
    userId = serializers.SerializerMethodField()
    createTime = serializers.SerializerMethodField()

    class Meta:
        model = Lost
        fields = '__all__'

    def get_categoryId(self, obj):
        return obj.category_id
    def get_userId(self, obj):
        return obj.user_id
    def get_createTime(self, obj):
        return obj.create_time

# 物品类型
class Category(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="编号", help_text="编号")
    name = models.CharField(max_length=255, verbose_name="分类名称 ", null=True, blank=True, help_text="分类名称")


    class Meta:
        db_table = "category"
        verbose_name = "物品类型"
        verbose_name_plural = verbose_name

class CategorySerializer(serializers.ModelSerializer):

    class Meta:
        model = Category
        fields = '__all__'


# 待申领信息
class Cart(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="申领编号", help_text="申领编号")
    user_id = models.IntegerField(verbose_name="申领用户", null=True, blank=True, help_text="申领用户")
    name = models.CharField(max_length=255, verbose_name="申领物品 ", null=True, blank=True, help_text="申领物品")
    img = models.CharField(max_length=255, verbose_name="物品图片 ", null=True, blank=True, help_text="物品图片")
    biz_user_id = models.IntegerField(verbose_name="拾取物品人", null=True, blank=True, help_text="拾取物品人")
    goodid = models.IntegerField(verbose_name="物品编号", null=True, blank=True, help_text="物品编号")

    @property
    def userId(self):
        return self.user_id
    @property
    def bizUserId(self):
        return self.biz_user_id

    class Meta:
        db_table = "cart"
        verbose_name = "待申领信息"
        verbose_name_plural = verbose_name

class CartSerializer(serializers.ModelSerializer):
    userId = serializers.SerializerMethodField()
    bizUserId = serializers.SerializerMethodField()

    class Meta:
        model = Cart
        fields = '__all__'

    def get_userId(self, obj):
        return obj.user_id
    def get_bizUserId(self, obj):
        return obj.biz_user_id

# 失物申领记录
class Orders(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="申领编号", help_text="申领编号")
    name = models.CharField(max_length=255, verbose_name="申领号 ", null=True, blank=True, help_text="申领号")
    content = models.TextField(verbose_name="申领明细 ",null=True, blank=True,  help_text="申领明细")
    state_radio = models.CharField(max_length=255, verbose_name="订单状态,申领中|确认为失主|已归还|已取消 ", null=True, blank=True, help_text="订单状态,申领中|确认为失主|已归还|已取消")
    user_id = models.IntegerField(verbose_name="申领用户", null=True, blank=True, help_text="申领用户")
    create_time = models.DateTimeField(auto_now_add=True, null=True, blank=True, help_text="申领时间", verbose_name="申领时间")
    update_time = models.DateTimeField(auto_now=True, null=True, blank=True, help_text="更新时间",verbose_name="更新时间")
    biz_user_id = models.IntegerField(verbose_name="失物拾取人", null=True, blank=True, help_text="失物拾取人")
    goodids = models.CharField(max_length=255, verbose_name="物品编号 ", null=True, blank=True, help_text="物品编号")

    @property
    def stateRadio(self):
        return self.state_radio
    @property
    def userId(self):
        return self.user_id
    @property
    def createTime(self):
        return self.create_time
    @property
    def updateTime(self):
        return self.update_time
    @property
    def bizUserId(self):
        return self.biz_user_id

    class Meta:
        db_table = "orders"
        verbose_name = "失物申领记录"
        verbose_name_plural = verbose_name

class OrdersSerializer(serializers.ModelSerializer):
    stateRadio = serializers.SerializerMethodField()
    userId = serializers.SerializerMethodField()
    createTime = serializers.SerializerMethodField()
    updateTime = serializers.SerializerMethodField()
    bizUserId = serializers.SerializerMethodField()

    class Meta:
        model = Orders
        fields = '__all__'

    def get_stateRadio(self, obj):
        return obj.state_radio
    def get_userId(self, obj):
        return obj.user_id
    def get_createTime(self, obj):
        return obj.create_time
    def get_updateTime(self, obj):
        return obj.update_time
    def get_bizUserId(self, obj):
        return obj.biz_user_id


# 轮播图
class Banner(models.Model):
    id = models.AutoField(primary_key=True, verbose_name="轮播图编号", help_text="轮播图编号")
    img = models.CharField(max_length=255, verbose_name="图片 ", null=True, blank=True, help_text="图片")
    url = models.CharField(max_length=255, verbose_name="链接地址 ", null=True, blank=True, help_text="链接地址")
    index_radio = models.CharField(max_length=255, verbose_name="是否首页 ", null=True, blank=True, help_text="是否首页")

    @property
    def indexRadio(self):
        return self.index_radio

    class Meta:
        db_table = "banner"
        verbose_name = "轮播图"
        verbose_name_plural = verbose_name

class BannerSerializer(serializers.ModelSerializer):
    indexRadio = serializers.SerializerMethodField()

    class Meta:
        model = Banner
        fields = '__all__'

    def get_indexRadio(self, obj):
        return obj.index_radio

