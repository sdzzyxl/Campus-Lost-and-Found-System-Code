export default {
    serverUrl: 'localhost:9090',
	projectName: '失物招领系统',
}
